#CA PAM Settings - location of folder and executable for the pam client
export CSPM_CLIENT_HOME=/home/infa/ca_pam/cspm
export CSPM_CLIENT_BINARY=cspmclient

# EDC api settings - edc url with host and port
# both edc settings can be placed into .env file if needed
export INFA_EDC_URL=https://napslxapp01:9085
# encoded credentials for edc user - must have permissions use rest api and edit resource privileges
# use python encodeUser.py to create the right setting  
export INFA_EDC_AUTH="Basic xxxxxxxxxxxxxxxx"

# infa platform infacmd settings
# create encrypted domain password with $INFA_HOME//server/bin/pmpasswd <password to encrypt>
export INFA_DEFAULT_DOMAIN_USER=Administrator
export INFA_DEFAULT_DOMAIN_PASSWORD=""
